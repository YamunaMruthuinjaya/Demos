package com.cg.service;

public interface SessionManager {
	
	public Object createSession();
	public boolean addDataToSession(Object obj);
	public  boolean removeDataFromSession(String attributeName);
	public boolean destroySession();
	

}
