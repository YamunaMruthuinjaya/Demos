package com.cg.service;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cg.dao.UserDao;
import com.cg.models.Role;
import com.cg.models.User;
import com.cg.models.UserStatus;

/*@Service("userDetailsService")*/
public class UserDetailsServiceImpl implements UserDetailsService {
	
	/*@Autowired*/
	private UserDao userDao;

	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		User user = userDao.findUserByName(userName);
		
		if(user!=null){
			System.out.println(user.getUsernname());
			System.out.println(user.getPassword());
			String password = user.getPassword();
			boolean enabled = user.getStatus().equals(UserStatus.ACTIVE);
			boolean credentialsNonExpired = user.getStatus().equals(UserStatus.ACTIVE);
			boolean accountNonExpired = user.getStatus().equals(UserStatus.ACTIVE);
			boolean accountNonLocked = user.getStatus().equals(UserStatus.ACTIVE);
			
			Collection<GrantedAuthority> authorities = buildUserAuthority(user.getRoles());
			//Spring Security user object
			org.springframework.security.core.userdetails.User secureUser = 
					new org.springframework.security.core.userdetails.User(userName, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);
			return secureUser;
		}
		else{
			throw new UsernameNotFoundException("User Not Found");
		}
		
	}
	
	private List<GrantedAuthority> buildUserAuthority(List<Role> userRoles) {

		Set<GrantedAuthority> setAuths = new HashSet<GrantedAuthority>();

		// Build user's authorities
		for (Role userRole : userRoles) {
			if(userRole.getRolename().equals("ADMIN")){
				System.out.println("User role is "+userRole.getRolename());
				userRole.setRolename("ROLE_ADMIN");
			}
			else if (userRole.getRolename().equals("USER")) {
				System.out.println("User role is "+userRole.getRolename());
				userRole.setRolename("ROLE_USER");
			}
			
			setAuths.add(new SimpleGrantedAuthority(userRole.getRolename()));
		}

		List<GrantedAuthority> result = new ArrayList<GrantedAuthority>(setAuths);

		return result;
	}
	
	public UserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

}
