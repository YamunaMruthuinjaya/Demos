package com.cg.service;

public class First extends SessionManagerImpl {
	
	

}
