package com.cg.service;

public class Second extends SessionManagerImpl {

}
