package com.cg.service;

public class UserSession {
	public SessionManager getObject(String classname){
		if(classname == null){
	         return null;
	      }		
	      if(classname.equalsIgnoreCase("First")){
	         return new First();
	         
	      } else if(classname.equalsIgnoreCase("Second")){
	         return new Second();
	         
	      } 
	      return null;
		
	}
	
	
	
}
