package com.cg.models;

public enum UserStatus {
	ACTIVE,
	INACTIVE;
}
