package com.cg.dao;

import java.util.List;

import com.cg.models.User;

public interface UserDao {
	
	void addUser(User user);
	void editUser(User user);
	void deleteUser(Integer userId);
	User findUser(Integer userId);
	User findUserByName(String userName);
	List<User> getAllUsers();

}
