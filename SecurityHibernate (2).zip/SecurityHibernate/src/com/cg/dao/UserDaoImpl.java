package com.cg.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import com.cg.models.User;


public class UserDaoImpl implements UserDao {
	
	private SessionFactory sessionFactory;
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void addUser(User user) {
		sessionFactory.openSession().save(user);
	}

	@Override
	public void editUser(User user) {
		sessionFactory.openSession().update(user);

	}

	@Override
	public void deleteUser(Integer userId) {
		sessionFactory.openSession().delete(findUser(userId));

	}

	@Override
	public User findUser(Integer userId) {
		return (User) sessionFactory.openSession().get(User.class, userId);
	}

	@Override
	public User findUserByName(String userName) {
		List<User> users = sessionFactory.openSession().createQuery("from User where username=?").setParameter(0, userName).list();
		if(users.size()>0){
			return users.get(0);
		}
		else{
			return null;
		}
	}

	@Override
	public List<User> getAllUsers() {
		return sessionFactory.openSession().createQuery("from User").list();
	}

}
