package com.capgemini.LoginService;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.Login.LoginInfoRes;
import com.capgemini.Login.LoginInfoReq;

@RestController
@RequestMapping(value = "/login")
public class LoginController {
	
	@RequestMapping(method = RequestMethod.POST)
	public @ResponseBody
	LoginInfoRes login(@RequestBody LoginInfoReq loginInfo)
	{
		LoginInfoRes loginReturn = new LoginInfoRes();
		
		if(loginInfo.getLoginId().equals(loginInfo.getPassowrd()))
		{
			loginReturn.setIsSuccess(Boolean.TRUE);
		}
		else {
			loginReturn.setIsSuccess(Boolean.FALSE);
		}
		
	    return loginReturn;
	}

}
