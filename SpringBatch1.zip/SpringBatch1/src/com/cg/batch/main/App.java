package com.cg.batch.main;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		System.out.println("in main");
		String[] springConfig=
			{
					"/com/cg/xml/spring-database.xml",
					"/com/cg/xml/spring-context.xml",
					"/com/cg/xml/job.xml"
			};
		ApplicationContext  context=new ClassPathXmlApplicationContext(springConfig);
		JobLauncher jl=(JobLauncher)context.getBean("jobLauncher");
		Job job=(Job)context.getBean("reportJob");
		try{
			JobExecution exe= jl.run(job,new JobParameters());
			System.out.println("completed"+exe.getStatus());
		}
		catch(Exception e){
			System.out.println("exception");
		}
System.out.println("done");
	}

}
