package com.cg.batch.main;

import javax.persistence.Entity;

@Entity
public class CopyStudent {
	
	private int copystudentid;
	
	private String copystudentname;

	public int getCopystudentid() {
		return copystudentid;
	}

	public void setCopystudentid(int copystudentid) {
		this.copystudentid = copystudentid;
	}

	public String getCopystudentname() {
		return copystudentname;
	}

	public void setCopystudentname(String copystudentname) {
		this.copystudentname = copystudentname;
	}

	@Override
	public String toString() {
		return "CopyStudent [copystudentid=" + copystudentid + ", copystudentname=" + copystudentname + "]";
	}
	
	

}
