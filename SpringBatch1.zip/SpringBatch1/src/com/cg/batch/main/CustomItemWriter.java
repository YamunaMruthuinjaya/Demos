package com.cg.batch.main;

import java.util.List;


import org.springframework.batch.item.ItemWriter;

public class CustomItemWriter implements ItemWriter<CopyStudent> {

	@Override
	public void write(List<? extends CopyStudent> arg0) throws Exception {
	
		
	}

}
