package com.cg.batch.main;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class StudentRowMapper implements RowMapper<Student> {

	@Override
	public Student mapRow(ResultSet resultset, int rownum) throws SQLException {
		Student student=new Student();
		student.setStudentid(resultset.getInt(1));
		student.setStudentname(resultset.getString(2));
		return student;
	}
	
	
	

}
